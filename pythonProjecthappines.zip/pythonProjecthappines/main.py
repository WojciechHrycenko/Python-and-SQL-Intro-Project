import streamlit as st
import plotly.express as px
import pandas as pd

df = pd.read_csv("happy.csv")

st.title("In Search of Happiness")

horizontal_text = st.selectbox("Select the data for the X-axis", ("happiness", "gdp", "corruption"))
vertical_text = st.selectbox("Select the data for the Y-axis ", ("happiness", "gdp", "corruption"))


match horizontal_text:
    case "happiness":
        horizontal = df["happiness"]
    case "gdp":
        horizontal = df["gdp"]
    case "corruption":
        horizontal = df["corruption"]

match vertical_text:
    case "happiness":
        vertical = df["happiness"]
    case "gdp":
        vertical = df["gdp"]
    case "corruption":
        vertical = df["corruption"]

figure = px.scatter(x=horizontal, y=vertical, labels= {"x": horizontal_text, "y": vertical_text} )
st.plotly_chart(figure)
